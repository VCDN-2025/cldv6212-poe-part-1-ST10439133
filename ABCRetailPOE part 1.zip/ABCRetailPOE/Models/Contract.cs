﻿namespace ABCRetailPOE.Models
{
    public class Contract
    {
        public string FileName { get; set; } = string.Empty;

    }
}
